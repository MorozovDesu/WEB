

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route("flower-objects.create")); ?>" method = "POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input class="form-control mb-2" type="text"  name="title">
        <input class="form-control mb-2" type="text"  name="description">
        <input class="form-control mb-2" type="file" name="image">
        <button class="btn btn-primary">Создать</button>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('__layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel\resources\views/object_create.blade.php ENDPATH**/ ?>