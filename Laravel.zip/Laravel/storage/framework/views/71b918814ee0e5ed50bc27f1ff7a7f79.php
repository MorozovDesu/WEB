

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__currentLoopData = $objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4 p-2">
                <div class="d-flex flex-column border p-2">
                    <img src="<?php echo e($object->imageUrl); ?>" alt="" sizes="max-width: 100%; height: 200px; object-fit: cover;">
                    <a href="/flower-objects/<?php echo e($object->id); ?>" class="btn btn-primary w-100 mt-3">
                        <?php echo e($object->title); ?>

                    </a>
                    <div class="d-flex justify-content-between mt-3">
                        <button class="btn btn-primary">Картинка</button>
                        <button class="btn btn-primary">Описание</button>
                        <a href="<?php echo e(route('flower-objects.edit', $object->id)); ?>" class="btn btn-success">Edit</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('__layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel\resources\views/main.blade.php ENDPATH**/ ?>