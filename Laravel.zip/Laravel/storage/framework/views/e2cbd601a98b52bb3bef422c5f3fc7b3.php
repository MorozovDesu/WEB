

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('flower-objects.update', ['id' => $object->id])); ?>" method = "POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input class="form-control mb-2" type="text" value="<?php echo e($object->title); ?>" name="title">
        <input class="form-control mb-2" type="text" value="<?php echo e($object->description); ?>" name="description">
        <input class="form-control mb-2" type="file" name="image">
        <button class="btn btn-primary">Обновить</button>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('__layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel\resources\views/object_edit.blade.php ENDPATH**/ ?>