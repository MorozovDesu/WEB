

<?php $__env->startSection('content'); ?>
    <form action="" method = "POST" >
        <?php echo csrf_field(); ?>
        <input class="form-control mb-2" placeholder="email" type="text"  name="email">
        <input class="form-control mb-2" placeholder="password" type="password"  name="password">
        <button class="btn btn-primary" type="submit">Войти</button>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('__layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\Laravel\resources\views/login.blade.php ENDPATH**/ ?>