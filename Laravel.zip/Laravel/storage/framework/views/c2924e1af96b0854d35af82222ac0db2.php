

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('flower-objects.update', ['flower_object' => $object->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field("put"); ?>
        <div class="mb-3">
            <label class="form-label">Название</label>
            <input class="form-control mb-2" type="text" value="<?php echo e($object->title); ?>" name="title">
        </div>
        <div class="mb-3">
            <label class="form-label">Краткое описание</label>
            <input class="form-control mb-2" type="text" value="<?php echo e($object->description); ?>" name="description">
        </div>
        <div class="mb-3">
            <label class="form-label">Полное описание</label>
            <textarea class="form-control mb-2" name="info" rows="5"><?php echo e($object->info); ?></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Тип</label>
            <select class="form-control" name="type">
                <option value="кустовые" <?php echo e($object->type == 'кустовые' ? 'selected' : ''); ?>>Кустовые</option>
                <option value="одиночные" <?php echo e($object->type == 'одиночные' ? 'selected' : ''); ?>>Одиночные</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Картинка</label>
            <input class="form-control mb-2" type="file" name="image">
        </div>
        <button class="btn btn-primary">Обновить</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('__layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\Laravel\resources\views/object_edit.blade.php ENDPATH**/ ?>