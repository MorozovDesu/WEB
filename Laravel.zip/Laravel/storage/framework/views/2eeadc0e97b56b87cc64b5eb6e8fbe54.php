

<?php $__env->startSection('content'); ?>
    <div class="row d-flex">
        <?php $__currentLoopData = $objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4 p-2" style="margin-bottom: 100px;">
                <div class="position-relative border p-2" style="height: 300px; width: 100%;">
                    <img src="<?php echo e($object->imageUrl); ?>" alt="" style="width: 100%; height: 100%; object-fit: cover;">
                    <a href="<?php echo e(route('flower-objects.show', [$object->id, 'show' => 'image'])); ?>" class="btn btn-primary w-100 mt-2">
                        <?php echo e($object->title); ?>

                    </a>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="position-absolute top-0 end-0 mt-0 me-2">
                            <a href="<?php echo e(route('flower-objects.edit', $object->id)); ?>" class="btn btn-success">Edit</a>
                            <form action="<?php echo e(route('flower-objects.destroy', $object->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn  btn-danger">Delete</button>
                            </form>
                        </div>
                    <?php endif; ?>
                    <div class="d-flex justify-content-between mt-1">
                        <a href="<?php echo e(route('flower-objects.show', [$object->id, 'show' => 'image'])); ?>" class="btn btn-primary">Картинка</a>
                        <a href="<?php echo e(route('flower-objects.show', [$object->id, 'show' => 'info'])); ?>" class="btn btn-primary">Описание</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('__layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\Laravel\resources\views/main.blade.php ENDPATH**/ ?>